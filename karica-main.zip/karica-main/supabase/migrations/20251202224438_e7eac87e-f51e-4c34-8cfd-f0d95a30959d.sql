-- Enable realtime for lead_messages table
ALTER PUBLICATION supabase_realtime ADD TABLE public.lead_messages;